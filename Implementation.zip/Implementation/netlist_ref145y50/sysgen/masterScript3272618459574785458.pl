
open(PIDFILE, '> pidfile.txt') || die 'Couldn\'t write process ID to file.';
print PIDFILE "$$\n";
close(PIDFILE);

eval {
  # Call script(s).
  my $instrs;
  my $results = [];
$ENV{'SYSGEN'} = 'C:/Xilinx/14.5/ISE_DS/ISE/sysgen';
  use Sg;
  $instrs = {
    'HDLCodeGenStatus' => 0.0,
    'HDL_PATH' => 'C:/Users/alber/Documents/UTM - Maestria/Tesis Maestria/6 Implementacion XSG',
    'Impl_file' => 'ISE Defaults',
    'Impl_file_sgadvanced' => '',
    'Synth_file' => 'XST Defaults',
    'Synth_file_sgadvanced' => '',
    'TEMP' => 'C:/Users/alber/AppData/Local/Temp',
    'TMP' => 'C:/Users/alber/AppData/Local/Temp',
    'Temp' => 'C:/Users/alber/AppData/Local/Temp',
    'Tmp' => 'C:/Users/alber/AppData/Local/Temp',
    'base_system_period_hardware' => 10.0,
    'base_system_period_simulink' => 2.0E-6,
    'block_icon_display' => 'Default',
    'block_type' => 'sysgen',
    'block_version' => '',
    'ce_clr' => 0.0,
    'clock_domain' => 'default',
    'clock_loc' => 'E3',
    'clock_wrapper' => 'Clock Enables',
    'clock_wrapper_sgadvanced' => '',
    'compilation' => 'HDL Netlist',
    'compilation_lut' => {
      'keys' => [
        'HDL Netlist',
        'Bitstream',
      ],
      'values' => [
        'target1',
        'target2',
      ],
    },
    'compilation_target' => 'HDL Netlist',
    'core_generation' => 1.0,
    'core_generation_sgadvanced' => '',
    'core_is_deployed' => 0.0,
    'coregen_core_generation_tmpdir' => 'C:/Users/alber/AppData/Local/Temp/sysgentmp-alber/cg_wk/c4cd6d0d0e3051c4f',
    'coregen_part_family' => 'artix7',
    'createTestbench' => 0,
    'create_interface_document' => 'off',
    'dbl_ovrd' => -1.0,
    'dbl_ovrd_sgadvanced' => '',
    'dcm_input_clock_period' => 10.0,
    'deprecated_control' => 'off',
    'deprecated_control_sgadvanced' => '',
    'design' => 'e_MPPT_BuckMotor_XSG_Implementacion',
    'design_full_path' => 'C:\\Users\\alber\\Documents\\UTM - Maestria\\Tesis Maestria\\6 Implementacion XSG\\e_MPPT_BuckMotor_XSG_Implementacion.slx',
    'device' => 'xc7a100t-1csg324',
    'device_speed' => '-1',
    'directory' => 'C:/Users/alber/Documents/UTM - Maestria/Tesis Maestria/6 Implementacion XSG/netlist',
    'dsp_cache_root_path' => 'C:/Users/alber/AppData/Local/Temp/sysgentmp-alber',
    'eval_field' => '0',
    'fileDeliveryDefaults' => [
      [
        '(?i)\\.vhd$',
        { 'fileName' => 'C:/Users/alber/Documents/UTM - Maestria/Tesis Maestria/6 Implementacion XSG/netlist/sysgen/perl_results.vhd', },
      ],
      [
        '(?i)\\.v$',
        { 'fileName' => 'C:/Users/alber/Documents/UTM - Maestria/Tesis Maestria/6 Implementacion XSG/netlist/sysgen/perl_results.v', },
      ],
    ],
    'force_scheduling' => 0.0,
    'fxdptinstalled' => 1.0,
    'generateUsing71FrontEnd' => 1,
    'generating_island_subsystem_handle' => 2079.000244140625,
    'generating_subsystem_handle' => 2079.000244140625,
    'generation_directory' => './netlist',
    'has_advanced_control' => '0',
    'hdlDir' => 'C:/Xilinx/14.5/ISE_DS/ISE/sysgen/hdl',
    'hdlKind' => 'vhdl',
    'hdl_path' => 'C:/Users/alber/Documents/UTM - Maestria/Tesis Maestria/6 Implementacion XSG',
    'impl_file' => 'ISE Defaults*',
    'incr_netlist' => 'off',
    'incr_netlist_sgadvanced' => '',
    'infoedit' => ' System Generator',
    'isdeployed' => 0,
    'ise_version' => '14.5i',
    'master_sysgen_token_handle' => 2080.2301025390625,
    'matlab' => 'C:/Program Files/MATLAB/R2012b',
    'matlab_fixedpoint' => 1.0,
    'mdlHandle' => 2079.000244140625,
    'mdlPath' => 'C:/Users/alber/Documents/UTM - Maestria/Tesis Maestria/6 Implementacion XSG/e_MPPT_BuckMotor_XSG_Implementacion.mdl',
    'modelDiagnostics' => [
      {
        'count' => 457.0,
        'isMask' => 0.0,
        'type' => 'e_MPPT_BuckMotor_XSG_Implementacion Total blocks',
      },
      {
        'count' => 2.0,
        'isMask' => 0.0,
        'type' => 'DiscretePulseGenerator',
      },
      {
        'count' => 101.0,
        'isMask' => 0.0,
        'type' => 'Inport',
      },
      {
        'count' => 52.0,
        'isMask' => 0.0,
        'type' => 'Outport',
      },
      {
        'count' => 269.0,
        'isMask' => 0.0,
        'type' => 'S-Function',
      },
      {
        'count' => 31.0,
        'isMask' => 0.0,
        'type' => 'SubSystem',
      },
      {
        'count' => 2.0,
        'isMask' => 0.0,
        'type' => 'Terminator',
      },
      {
        'count' => 36.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Adder/Subtracter Block',
      },
      {
        'count' => 11.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Arithmetic Relational Operator Block',
      },
      {
        'count' => 6.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Black Box Block',
      },
      {
        'count' => 12.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Bus Multiplexer Block',
      },
      {
        'count' => 43.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Constant Block Block',
      },
      {
        'count' => 19.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Constant Multiplier Block',
      },
      {
        'count' => 2.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Counter Block',
      },
      {
        'count' => 2.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Delay Block',
      },
      {
        'count' => 8.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Gateway In Block',
      },
      {
        'count' => 14.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Gateway Out Block',
      },
      {
        'count' => 2.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Logical Block Block',
      },
      {
        'count' => 70.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Multiplier Block',
      },
      {
        'count' => 18.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Register Block',
      },
      {
        'count' => 1.0,
        'isMask' => 1.0,
        'type' => 'Xilinx System Generator Block',
      },
      {
        'count' => 26.0,
        'isMask' => 1.0,
        'type' => 'Xilinx Type Converter Block',
      },
    ],
    'model_globals_initialized' => 1.0,
    'model_path' => 'C:/Users/alber/Documents/UTM - Maestria/Tesis Maestria/6 Implementacion XSG/e_MPPT_BuckMotor_XSG_Implementacion.mdl',
    'myxilinx' => 'C:/Xilinx/14.5/ISE_DS/ISE',
    'ngc_files' => [ 'xlpersistentdff.ngc', ],
    'num_sim_cycles' => '7500000',
    'package' => 'csg324',
    'part' => 'xc7a100t',
    'partFamily' => 'artix7',
    'port_data_types_enabled' => 0.0,
    'preserve_hierarchy' => 0.0,
    'proj_type' => 'Project Navigator',
    'proj_type_sgadvanced' => '',
    'report_true_rates' => 0.0,
    'run_coregen' => 'off',
    'run_coregen_sgadvanced' => '',
    'sample_time_colors_enabled' => 0.0,
    'sampletimecolors' => 0.0,
    'sg_blockgui_xml' => '',
    'sg_icon_stat' => '50,50,-1,-1,token,white,0,07734,right,,[ ],[ ]',
    'sg_list_contents' => '',
    'sg_mask_display' => 'fprintf(\'\',\'COMMENT: begin icon graphics\');
patch([0 50 50 0 0 ],[0 0 50 50 0 ],[1 1 1 ]);
patch([1.6375 16.81 27.31 37.81 48.31 27.31 12.1375 1.6375 ],[36.655 36.655 47.155 36.655 47.155 47.155 47.155 36.655 ],[0.933333 0.203922 0.141176 ]);
patch([12.1375 27.31 16.81 1.6375 12.1375 ],[26.155 26.155 36.655 36.655 26.155 ],[0.698039 0.0313725 0.219608 ]);
patch([1.6375 16.81 27.31 12.1375 1.6375 ],[15.655 15.655 26.155 26.155 15.655 ],[0.933333 0.203922 0.141176 ]);
patch([12.1375 48.31 37.81 27.31 16.81 1.6375 12.1375 ],[5.155 5.155 15.655 5.155 15.655 15.655 5.155 ],[0.698039 0.0313725 0.219608 ]);
fprintf(\'\',\'COMMENT: end icon graphics\');
fprintf(\'\',\'COMMENT: begin icon text\');
fprintf(\'\',\'COMMENT: end icon text\');',
    'sg_version' => '',
    'sggui_pos' => '-1,-1,-1,-1',
    'simulation_island_subsystem_handle' => 2079.000244140625,
    'simulink_accelerator_running' => 0.0,
    'simulink_debugger_running' => 0.0,
    'simulink_period' => 2.0E-6,
    'speed' => '-1',
    'synth_file' => 'XST Defaults*',
    'synthesisTool' => 'XST',
    'synthesis_language' => 'vhdl',
    'synthesis_tool' => 'XST',
    'synthesis_tool_sgadvanced' => '',
    'sysclk_period' => 10.0,
    'sysgen' => 'C:/Xilinx/14.5/ISE_DS/ISE/sysgen',
    'sysgenRoot' => 'C:/Xilinx/14.5/ISE_DS/ISE/sysgen',
    'sysgenTokenSettings' => {
      'Impl_file' => 'ISE Defaults',
      'Impl_file_sgadvanced' => '',
      'Synth_file' => 'XST Defaults',
      'Synth_file_sgadvanced' => '',
      'base_system_period_hardware' => 10.0,
      'base_system_period_simulink' => 2.0E-6,
      'block_icon_display' => 'Default',
      'block_type' => 'sysgen',
      'block_version' => '',
      'ce_clr' => 0.0,
      'clock_loc' => 'E3',
      'clock_wrapper' => 'Clock Enables',
      'clock_wrapper_sgadvanced' => '',
      'compilation' => 'HDL Netlist',
      'compilation_lut' => {
        'keys' => [
          'HDL Netlist',
          'Bitstream',
        ],
        'values' => [
          'target1',
          'target2',
        ],
      },
      'core_generation' => 1.0,
      'core_generation_sgadvanced' => '',
      'coregen_part_family' => 'artix7',
      'create_interface_document' => 'off',
      'dbl_ovrd' => -1.0,
      'dbl_ovrd_sgadvanced' => '',
      'dcm_input_clock_period' => 10.0,
      'deprecated_control' => 'off',
      'deprecated_control_sgadvanced' => '',
      'directory' => './netlist',
      'eval_field' => '0',
      'has_advanced_control' => '0',
      'impl_file' => 'ISE Defaults*',
      'incr_netlist' => 'off',
      'incr_netlist_sgadvanced' => '',
      'infoedit' => ' System Generator',
      'master_sysgen_token_handle' => 2080.2301025390625,
      'package' => 'csg324',
      'part' => 'xc7a100t',
      'preserve_hierarchy' => 0.0,
      'proj_type' => 'Project Navigator',
      'proj_type_sgadvanced' => '',
      'run_coregen' => 'off',
      'run_coregen_sgadvanced' => '',
      'sg_blockgui_xml' => '',
      'sg_icon_stat' => '50,50,-1,-1,token,white,0,07734,right,,[ ],[ ]',
      'sg_list_contents' => '',
      'sg_mask_display' => 'fprintf(\'\',\'COMMENT: begin icon graphics\');
patch([0 50 50 0 0 ],[0 0 50 50 0 ],[1 1 1 ]);
patch([1.6375 16.81 27.31 37.81 48.31 27.31 12.1375 1.6375 ],[36.655 36.655 47.155 36.655 47.155 47.155 47.155 36.655 ],[0.933333 0.203922 0.141176 ]);
patch([12.1375 27.31 16.81 1.6375 12.1375 ],[26.155 26.155 36.655 36.655 26.155 ],[0.698039 0.0313725 0.219608 ]);
patch([1.6375 16.81 27.31 12.1375 1.6375 ],[15.655 15.655 26.155 26.155 15.655 ],[0.933333 0.203922 0.141176 ]);
patch([12.1375 48.31 37.81 27.31 16.81 1.6375 12.1375 ],[5.155 5.155 15.655 5.155 15.655 15.655 5.155 ],[0.698039 0.0313725 0.219608 ]);
fprintf(\'\',\'COMMENT: end icon graphics\');
fprintf(\'\',\'COMMENT: begin icon text\');
fprintf(\'\',\'COMMENT: end icon text\');',
      'sggui_pos' => '-1,-1,-1,-1',
      'simulation_island_subsystem_handle' => 2079.000244140625,
      'simulink_period' => 2.0E-6,
      'speed' => '-1',
      'synth_file' => 'XST Defaults*',
      'synthesis_language' => 'vhdl',
      'synthesis_tool' => 'XST',
      'synthesis_tool_sgadvanced' => '',
      'sysclk_period' => 10.0,
      'testbench' => 0,
      'testbench_sgadvanced' => '',
      'trim_vbits' => 1.0,
      'trim_vbits_sgadvanced' => '',
      'xilinx_device' => 'xc7a100t-1csg324',
      'xilinxfamily' => 'artix7',
    },
    'sysgen_Root' => 'C:/Xilinx/14.5/ISE_DS/ISE/sysgen',
    'systemClockPeriod' => 10.0,
    'tempdir' => 'C:/Users/alber/AppData/Local/Temp',
    'testbench' => 0,
    'testbench_sgadvanced' => '',
    'tmpDir' => 'C:/Users/alber/Documents/UTM - Maestria/Tesis Maestria/6 Implementacion XSG/netlist/sysgen',
    'trim_vbits' => 1.0,
    'trim_vbits_sgadvanced' => '',
    'use_strict_names' => 1,
    'user_tips_enabled' => 0.0,
    'usertemp' => 'C:/Users/alber/AppData/Local/Temp/sysgentmp-alber',
    'using71Netlister' => 1,
    'verilog_files' => [
      'conv_pkg.v',
      'synth_reg.v',
      'synth_reg_w_init.v',
      'convert_type.v',
    ],
    'version' => '',
    'vhdl_files' => [
      'conv_pkg.vhd',
      'synth_reg.vhd',
      'synth_reg_w_init.vhd',
    ],
    'vsimtime' => '82500275.000000 ns',
    'xilinx' => 'C:/Xilinx/14.5/ISE_DS/ISE',
    'xilinx_device' => 'xc7a100t-1csg324',
    'xilinx_family' => 'artix7',
    'xilinx_package' => 'csg324',
    'xilinx_part' => 'xc7a100t',
    'xilinxdevice' => 'xc7a100t-1csg324',
    'xilinxfamily' => 'artix7',
    'xilinxpart' => 'xc7a100t',
  };
  push(@$results, &Sg::setAttributes($instrs));
  use SgDeliverFile;
  $instrs = {
    'collaborationName' => 'conv_pkg.vhd',
    'sourceFile' => 'hdl/conv_pkg.vhd',
    'templateKeyValues' => {},
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'collaborationName' => 'synth_reg.vhd',
    'sourceFile' => 'hdl/synth_reg.vhd',
    'templateKeyValues' => {},
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'collaborationName' => 'synth_reg_w_init.vhd',
    'sourceFile' => 'hdl/synth_reg_w_init.vhd',
    'templateKeyValues' => {},
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'collaborationName' => 'xlpersistentdff.ngc',
    'sourceFile' => 'hdl/xlpersistentdff.ngc',
    'templateKeyValues' => {},
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  use SgGenerateCores;
  $instrs = [
    'SELECT Floating-point artix7 Xilinx,_Inc. 6.1',
    '# 14.5_P.55',
    '# DEVICE artix7',
    '# VHDL',
    'CSET A_Precision_Type = Single',
    'CSET A_TUSER_Width = 1',
    'CSET Add_Sub_Value = Subtract',
    'CSET Axi_Optimize_Goal = Resources',
    'CSET B_TUSER_Width = 1',
    'CSET C_A_Exponent_Width = 8',
    'CSET C_A_Fraction_Width = 24',
    'CSET C_Compare_Operation = Programmable',
    'CSET C_Has_DIVIDE_BY_ZERO = false',
    'CSET C_Has_INVALID_OP = false',
    'CSET C_Has_OVERFLOW = false',
    'CSET C_Has_UNDERFLOW = false',
    'CSET C_Latency = 0',
    'CSET C_Mult_Usage = No_Usage',
    'CSET C_Optimization = Speed_Optimized',
    'CSET C_Rate = 1',
    'CSET C_Result_Exponent_Width = 8',
    'CSET C_Result_Fraction_Width = 24',
    'CSET Flow_Control = NonBlocking',
    'CSET Has_ACLKEN = false',
    'CSET Has_ARESETn = false',
    'CSET Has_A_TLAST = false',
    'CSET Has_A_TUSER = false',
    'CSET Has_B_TLAST = false',
    'CSET Has_B_TUSER = false',
    'CSET Has_OPERATION_TLAST = false',
    'CSET Has_OPERATION_TUSER = false',
    'CSET Has_RESULT_TREADY = false',
    'CSET Maximum_Latency = false',
    'CSET OPERATION_TUSER_Width = 1',
    'CSET Operation_Type = Add_Subtract',
    'CSET RESULT_TLAST_Behv = Null',
    'CSET Result_Precision_Type = Single',
    'CSET component_name = addsb_6_1_7698b099982b4045',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '2edb7523f5902656e91cddde51c3d85d',
    'sourceFile' => 'hdl/xlfpaddsub.vhd',
    'templateKeyValues' => {
      'core_component_def' => '    s_axis_a_tvalid: in std_logic;
    s_axis_a_tdata: in std_logic_vector(32 - 1 downto 0) :=(others=>\'0\');
    s_axis_b_tvalid: in std_logic;
    s_axis_b_tdata: in std_logic_vector(32 - 1 downto 0) :=(others=>\'0\');
    m_axis_result_tvalid: out std_logic;
    m_axis_result_tdata: out std_logic_vector(32- 1 downto 0) :=(others=>\'0\')',
      'core_instance_text' => '         s_axis_a_tvalid => a_tvalid_net,
         s_axis_a_tdata => a_tdata,
         s_axis_b_tvalid => b_tvalid_net,
         s_axis_b_tdata => b_tdata,
         m_axis_result_tvalid => result_tvalid_net,
         m_axis_result_tdata => result_tdata',
      'core_name0' => 'addsb_6_1_7698b099982b4045',
      'entityName' => 'xlfpaddsub_e_MPPT_BuckMotor_XSG_Implementacion',
      'entity_name.0' => 'xlfpaddsub',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Floating-point artix7 Xilinx,_Inc. 6.1',
    '# 14.5_P.55',
    '# DEVICE artix7',
    '# VHDL',
    'CSET A_Precision_Type = Single',
    'CSET A_TUSER_Width = 1',
    'CSET Add_Sub_Value = Add',
    'CSET Axi_Optimize_Goal = Resources',
    'CSET B_TUSER_Width = 1',
    'CSET C_A_Exponent_Width = 8',
    'CSET C_A_Fraction_Width = 24',
    'CSET C_Compare_Operation = Programmable',
    'CSET C_Has_DIVIDE_BY_ZERO = false',
    'CSET C_Has_INVALID_OP = false',
    'CSET C_Has_OVERFLOW = false',
    'CSET C_Has_UNDERFLOW = false',
    'CSET C_Latency = 0',
    'CSET C_Mult_Usage = No_Usage',
    'CSET C_Optimization = Speed_Optimized',
    'CSET C_Rate = 1',
    'CSET C_Result_Exponent_Width = 8',
    'CSET C_Result_Fraction_Width = 24',
    'CSET Flow_Control = NonBlocking',
    'CSET Has_ACLKEN = false',
    'CSET Has_ARESETn = false',
    'CSET Has_A_TLAST = false',
    'CSET Has_A_TUSER = false',
    'CSET Has_B_TLAST = false',
    'CSET Has_B_TUSER = false',
    'CSET Has_OPERATION_TLAST = false',
    'CSET Has_OPERATION_TUSER = false',
    'CSET Has_RESULT_TREADY = false',
    'CSET Maximum_Latency = false',
    'CSET OPERATION_TUSER_Width = 1',
    'CSET Operation_Type = Add_Subtract',
    'CSET RESULT_TLAST_Behv = Null',
    'CSET Result_Precision_Type = Single',
    'CSET component_name = addsb_6_1_d6fb3f09d8f9fd58',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '7099678fa01beae976b954209778cc14',
    'sourceFile' => 'hdl/xlfpaddsub.vhd',
    'templateKeyValues' => {
      'core_component_def' => '    s_axis_a_tvalid: in std_logic;
    s_axis_a_tdata: in std_logic_vector(32 - 1 downto 0) :=(others=>\'0\');
    s_axis_b_tvalid: in std_logic;
    s_axis_b_tdata: in std_logic_vector(32 - 1 downto 0) :=(others=>\'0\');
    m_axis_result_tvalid: out std_logic;
    m_axis_result_tdata: out std_logic_vector(32- 1 downto 0) :=(others=>\'0\')',
      'core_instance_text' => '         s_axis_a_tvalid => a_tvalid_net,
         s_axis_a_tdata => a_tdata,
         s_axis_b_tvalid => b_tvalid_net,
         s_axis_b_tdata => b_tdata,
         m_axis_result_tvalid => result_tvalid_net,
         m_axis_result_tdata => result_tdata',
      'core_name0' => 'addsb_6_1_d6fb3f09d8f9fd58',
      'entityName' => 'xlfpaddsub_e_MPPT_BuckMotor_XSG_Implementacion',
      'entity_name.0' => 'xlfpaddsub',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Floating-point artix7 Xilinx,_Inc. 6.1',
    '# 14.5_P.55',
    '# DEVICE artix7',
    '# VHDL',
    'CSET A_Precision_Type = Single',
    'CSET A_TUSER_Width = 1',
    'CSET Add_Sub_Value = Both',
    'CSET Axi_Optimize_Goal = Resources',
    'CSET B_TUSER_Width = 1',
    'CSET C_A_Exponent_Width = 8',
    'CSET C_A_Fraction_Width = 24',
    'CSET C_Compare_Operation = Programmable',
    'CSET C_Has_DIVIDE_BY_ZERO = false',
    'CSET C_Has_INVALID_OP = false',
    'CSET C_Has_OVERFLOW = false',
    'CSET C_Has_UNDERFLOW = false',
    'CSET C_Latency = 0',
    'CSET C_Mult_Usage = No_Usage',
    'CSET C_Optimization = Speed_Optimized',
    'CSET C_Rate = 1',
    'CSET C_Result_Exponent_Width = 8',
    'CSET C_Result_Fraction_Width = 24',
    'CSET Flow_Control = NonBlocking',
    'CSET Has_ACLKEN = false',
    'CSET Has_ARESETn = false',
    'CSET Has_A_TLAST = false',
    'CSET Has_A_TUSER = false',
    'CSET Has_B_TLAST = false',
    'CSET Has_B_TUSER = false',
    'CSET Has_OPERATION_TLAST = false',
    'CSET Has_OPERATION_TUSER = false',
    'CSET Has_RESULT_TREADY = false',
    'CSET Maximum_Latency = false',
    'CSET OPERATION_TUSER_Width = 1',
    'CSET Operation_Type = Multiply',
    'CSET RESULT_TLAST_Behv = Null',
    'CSET Result_Precision_Type = Single',
    'CSET component_name = cmlt_6_1_4a75c1800965883e',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => 'e3d752388b5886a07fbe42ff5c706285',
    'sourceFile' => 'hdl/xlfpcmult.vhd',
    'templateKeyValues' => {
      'core_component_def' => '    s_axis_a_tvalid: in std_logic;
    s_axis_a_tdata: in std_logic_vector(32 - 1 downto 0) :=(others=>\'0\');
    s_axis_b_tvalid: in std_logic;
    s_axis_b_tdata: in std_logic_vector(32 - 1 downto 0) :=(others=>\'0\');
    m_axis_result_tvalid: out std_logic;
    m_axis_result_tdata: out std_logic_vector(32- 1 downto 0) :=(others=>\'0\')',
      'core_instance_text' => '         s_axis_a_tvalid => a_tvalid_net,
         s_axis_a_tdata => a_tdata,
         s_axis_b_tvalid => b_tvalid_net,
         s_axis_b_tdata => b_tdata,
         m_axis_result_tvalid => result_tvalid_net,
         m_axis_result_tdata => result_tdata',
      'core_name0' => 'cmlt_6_1_4a75c1800965883e',
      'entityName' => 'xlfpcmult_e_MPPT_BuckMotor_XSG_Implementacion',
      'entity_name.0' => 'xlfpcmult',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '7522ca91e4767a1213b996450cc89130',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "00111011101000111101011100001010";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((32 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_6d6637232b',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'c8ac2f8b02c35d537ca2d762269f7a07',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "00000000000000000000000000000000";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((32 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_37567836aa',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'b2477aacdc33a884b1d98571f2a697f2',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "00111111100000000000000000000000";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((32 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_86aa27c164',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'aa29221d0f23ec8a7e591403a5bdb094',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "10111111100000000000000000000000";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((32 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_61d1238fc2',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = [
    'SELECT Floating-point artix7 Xilinx,_Inc. 6.1',
    '# 14.5_P.55',
    '# DEVICE artix7',
    '# VHDL',
    'CSET A_Precision_Type = Single',
    'CSET A_TUSER_Width = 1',
    'CSET Add_Sub_Value = Both',
    'CSET Axi_Optimize_Goal = Resources',
    'CSET B_TUSER_Width = 1',
    'CSET C_A_Exponent_Width = 8',
    'CSET C_A_Fraction_Width = 24',
    'CSET C_Compare_Operation = Programmable',
    'CSET C_Has_DIVIDE_BY_ZERO = false',
    'CSET C_Has_INVALID_OP = false',
    'CSET C_Has_OVERFLOW = false',
    'CSET C_Has_UNDERFLOW = false',
    'CSET C_Latency = 0',
    'CSET C_Mult_Usage = Max_Usage',
    'CSET C_Optimization = Speed_Optimized',
    'CSET C_Rate = 1',
    'CSET C_Result_Exponent_Width = 8',
    'CSET C_Result_Fraction_Width = 24',
    'CSET Flow_Control = NonBlocking',
    'CSET Has_ACLKEN = false',
    'CSET Has_ARESETn = false',
    'CSET Has_A_TLAST = false',
    'CSET Has_A_TUSER = false',
    'CSET Has_B_TLAST = false',
    'CSET Has_B_TUSER = false',
    'CSET Has_OPERATION_TLAST = false',
    'CSET Has_OPERATION_TUSER = false',
    'CSET Has_RESULT_TREADY = false',
    'CSET Maximum_Latency = false',
    'CSET OPERATION_TUSER_Width = 1',
    'CSET Operation_Type = Multiply',
    'CSET RESULT_TLAST_Behv = Null',
    'CSET Result_Precision_Type = Single',
    'CSET component_name = mlt_6_1_f2314e32a0d0b8e4',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '9dcc061303d3ef99222a1a8e081f04eb',
    'sourceFile' => 'hdl/xlfpmult.vhd',
    'templateKeyValues' => {
      'core_component_def' => '    s_axis_a_tvalid: in std_logic;
    s_axis_a_tdata: in std_logic_vector(32 - 1 downto 0) :=(others=>\'0\');
    s_axis_b_tvalid: in std_logic;
    s_axis_b_tdata: in std_logic_vector(32 - 1 downto 0) :=(others=>\'0\');
    m_axis_result_tvalid: out std_logic;
    m_axis_result_tdata: out std_logic_vector(32- 1 downto 0) :=(others=>\'0\')',
      'core_instance_text' => '         s_axis_a_tvalid => a_tvalid_net,
         s_axis_a_tdata => a_tdata,
         s_axis_b_tvalid => b_tvalid_net,
         s_axis_b_tdata => b_tdata,
         m_axis_result_tvalid => result_tvalid_net,
         m_axis_result_tdata => result_tdata',
      'core_name0' => 'mlt_6_1_f2314e32a0d0b8e4',
      'entityName' => 'xlfpmult_e_MPPT_BuckMotor_XSG_Implementacion',
      'entity_name.0' => 'xlfpmult',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '956cd09bb59dc534e292f2cc970b9f8d',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
  signal sel_1_20: std_logic;
  signal d0_1_24: std_logic_vector((32 - 1) downto 0);
  signal d1_1_27: std_logic_vector((32 - 1) downto 0);
  signal sel_internal_2_1_convert: std_logic_vector((1 - 1) downto 0);
  signal unregy_join_6_1: std_logic_vector((32 - 1) downto 0);
begin
  sel_1_20 <= sel(0);
  d0_1_24 <= d0;
  d1_1_27 <= d1;
  sel_internal_2_1_convert <= cast(std_logic_to_vector(sel_1_20), 0, 1, 0, xlUnsigned);
  proc_switch_6_1: process (d0_1_24, d1_1_27, sel_internal_2_1_convert)
  is
  begin
    case sel_internal_2_1_convert is 
      when "0" =>
        unregy_join_6_1 <= d0_1_24;
      when others =>
        unregy_join_6_1 <= d1_1_27;
    end case;
  end process proc_switch_6_1;
  y <= unregy_join_6_1;
end',
      'crippled_entity' => 'is
  port (
    sel : in std_logic_vector((1 - 1) downto 0);
    d0 : in std_logic_vector((32 - 1) downto 0);
    d1 : in std_logic_vector((32 - 1) downto 0);
    y : out std_logic_vector((32 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'mux_286b77e019',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '9ddd2176725f266acc1f79388f19a50a',
    'sourceFile' => 'C:/Xilinx/14.5/ISE_DS/ISE/sysgen/hdl/xlregister.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '9df0dfa6de52c3070905b506f6f53387',
    'sourceFile' => 'C:/Xilinx/14.5/ISE_DS/ISE/sysgen/hdl/xlregister.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Floating-point artix7 Xilinx,_Inc. 6.1',
    '# 14.5_P.55',
    '# DEVICE artix7',
    '# VHDL',
    'CSET A_Precision_Type = Single',
    'CSET A_TUSER_Width = 1',
    'CSET Add_Sub_Value = Both',
    'CSET Axi_Optimize_Goal = Resources',
    'CSET B_TUSER_Width = 1',
    'CSET C_A_Exponent_Width = 8',
    'CSET C_A_Fraction_Width = 24',
    'CSET C_Compare_Operation = Equal',
    'CSET C_Has_DIVIDE_BY_ZERO = false',
    'CSET C_Has_INVALID_OP = false',
    'CSET C_Has_OVERFLOW = false',
    'CSET C_Has_UNDERFLOW = false',
    'CSET C_Latency = 0',
    'CSET C_Mult_Usage = No_Usage',
    'CSET C_Optimization = Speed_Optimized',
    'CSET C_Rate = 1',
    'CSET C_Result_Exponent_Width = 1',
    'CSET C_Result_Fraction_Width = 0',
    'CSET Flow_Control = NonBlocking',
    'CSET Has_ACLKEN = false',
    'CSET Has_ARESETn = false',
    'CSET Has_A_TLAST = false',
    'CSET Has_A_TUSER = false',
    'CSET Has_B_TLAST = false',
    'CSET Has_B_TUSER = false',
    'CSET Has_OPERATION_TLAST = false',
    'CSET Has_OPERATION_TUSER = false',
    'CSET Has_RESULT_TREADY = false',
    'CSET Maximum_Latency = false',
    'CSET OPERATION_TUSER_Width = 1',
    'CSET Operation_Type = Compare',
    'CSET RESULT_TLAST_Behv = Null',
    'CSET Result_Precision_Type = Custom',
    'CSET component_name = rltnl_6_1_1fb93ae060797bcf',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '155f557282a460611f5ecdcd9c95cb7c',
    'sourceFile' => 'hdl/xlfprelational.vhd',
    'templateKeyValues' => {
      'core_component_def' => '    s_axis_a_tvalid: in std_logic;
    s_axis_a_tdata: in std_logic_vector(32 - 1 downto 0) :=(others=>\'0\');
    s_axis_b_tvalid: in std_logic;
    s_axis_b_tdata: in std_logic_vector(32 - 1 downto 0) :=(others=>\'0\');
    m_axis_result_tvalid: out std_logic;
    m_axis_result_tdata: out std_logic_vector(8- 1 downto 0) :=(others=>\'0\')',
      'core_instance_text' => '         s_axis_a_tvalid => a_tvalid_net,
         s_axis_a_tdata => a_tdata,
         s_axis_b_tvalid => b_tvalid_net,
         s_axis_b_tdata => b_tdata,
         m_axis_result_tvalid => result_tvalid_net,
         m_axis_result_tdata => result_tdata',
      'core_name0' => 'rltnl_6_1_1fb93ae060797bcf',
      'entityName' => 'xlfprelational_e_MPPT_BuckMotor_XSG_Implementacion',
      'entity_name.0' => 'xlfprelational',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Floating-point artix7 Xilinx,_Inc. 6.1',
    '# 14.5_P.55',
    '# DEVICE artix7',
    '# VHDL',
    'CSET A_Precision_Type = Single',
    'CSET A_TUSER_Width = 1',
    'CSET Add_Sub_Value = Both',
    'CSET Axi_Optimize_Goal = Resources',
    'CSET B_TUSER_Width = 1',
    'CSET C_A_Exponent_Width = 8',
    'CSET C_A_Fraction_Width = 24',
    'CSET C_Compare_Operation = Greater_Than',
    'CSET C_Has_DIVIDE_BY_ZERO = false',
    'CSET C_Has_INVALID_OP = false',
    'CSET C_Has_OVERFLOW = false',
    'CSET C_Has_UNDERFLOW = false',
    'CSET C_Latency = 0',
    'CSET C_Mult_Usage = No_Usage',
    'CSET C_Optimization = Speed_Optimized',
    'CSET C_Rate = 1',
    'CSET C_Result_Exponent_Width = 1',
    'CSET C_Result_Fraction_Width = 0',
    'CSET Flow_Control = NonBlocking',
    'CSET Has_ACLKEN = false',
    'CSET Has_ARESETn = false',
    'CSET Has_A_TLAST = false',
    'CSET Has_A_TUSER = false',
    'CSET Has_B_TLAST = false',
    'CSET Has_B_TUSER = false',
    'CSET Has_OPERATION_TLAST = false',
    'CSET Has_OPERATION_TUSER = false',
    'CSET Has_RESULT_TREADY = false',
    'CSET Maximum_Latency = false',
    'CSET OPERATION_TUSER_Width = 1',
    'CSET Operation_Type = Compare',
    'CSET RESULT_TLAST_Behv = Null',
    'CSET Result_Precision_Type = Custom',
    'CSET component_name = rltnl_6_1_9291a2c7bfc4fa3d',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '55cae6bc0e320c10c78caef1eb24d91f',
    'sourceFile' => 'hdl/xlfprelational.vhd',
    'templateKeyValues' => {
      'core_component_def' => '    s_axis_a_tvalid: in std_logic;
    s_axis_a_tdata: in std_logic_vector(32 - 1 downto 0) :=(others=>\'0\');
    s_axis_b_tvalid: in std_logic;
    s_axis_b_tdata: in std_logic_vector(32 - 1 downto 0) :=(others=>\'0\');
    m_axis_result_tvalid: out std_logic;
    m_axis_result_tdata: out std_logic_vector(8- 1 downto 0) :=(others=>\'0\')',
      'core_instance_text' => '         s_axis_a_tvalid => a_tvalid_net,
         s_axis_a_tdata => a_tdata,
         s_axis_b_tvalid => b_tvalid_net,
         s_axis_b_tdata => b_tdata,
         m_axis_result_tvalid => result_tvalid_net,
         m_axis_result_tdata => result_tdata',
      'core_name0' => 'rltnl_6_1_9291a2c7bfc4fa3d',
      'entityName' => 'xlfprelational_e_MPPT_BuckMotor_XSG_Implementacion',
      'entity_name.0' => 'xlfprelational',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '17909f8ebb31613818c3d275c218bef1',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "00111100101011110010011101101010";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((32 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_f9ebcb32b9',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'a828ba5598a5fc8eb6e1c4d63a1d06a7',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "00111010010100110100000001100111";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((32 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_ff5262847d',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '7813c10a5b20a55a20dfed48f6f1a741',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "01000000111011010111000010100100";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((32 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_0876833fb7',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'a1d3fc31ce58f6f69c6f2ddcd8bf41d3',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "00111111100001110000101000111101";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((32 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_68f63bbe5c',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '9d7e87a99e7db12039bf067bcbb51684',
    'sourceFile' => 'C:/Xilinx/14.5/ISE_DS/ISE/sysgen/hdl/xlconvert.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '1d710dd1a6596b030677426531c6ef01',
    'sourceFile' => 'C:/Xilinx/14.5/ISE_DS/ISE/sysgen/hdl/xlconvert.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Floating-point artix7 Xilinx,_Inc. 6.1',
    '# 14.5_P.55',
    '# DEVICE artix7',
    '# VHDL',
    'CSET A_Precision_Type = Int32',
    'CSET A_TUSER_Width = 1',
    'CSET Add_Sub_Value = Both',
    'CSET Axi_Optimize_Goal = Resources',
    'CSET B_TUSER_Width = 1',
    'CSET C_A_Exponent_Width = 32',
    'CSET C_A_Fraction_Width = 0',
    'CSET C_Compare_Operation = Programmable',
    'CSET C_Has_DIVIDE_BY_ZERO = false',
    'CSET C_Has_INVALID_OP = false',
    'CSET C_Has_OVERFLOW = false',
    'CSET C_Has_UNDERFLOW = false',
    'CSET C_Latency = 0',
    'CSET C_Mult_Usage = No_Usage',
    'CSET C_Optimization = Speed_Optimized',
    'CSET C_Rate = 1',
    'CSET C_Result_Exponent_Width = 8',
    'CSET C_Result_Fraction_Width = 24',
    'CSET Flow_Control = NonBlocking',
    'CSET Has_ACLKEN = false',
    'CSET Has_ARESETn = false',
    'CSET Has_A_TLAST = false',
    'CSET Has_A_TUSER = false',
    'CSET Has_B_TLAST = false',
    'CSET Has_B_TUSER = false',
    'CSET Has_OPERATION_TLAST = false',
    'CSET Has_OPERATION_TUSER = false',
    'CSET Has_RESULT_TREADY = false',
    'CSET Maximum_Latency = false',
    'CSET OPERATION_TUSER_Width = 1',
    'CSET Operation_Type = Fixed_to_float',
    'CSET RESULT_TLAST_Behv = Null',
    'CSET Result_Precision_Type = Single',
    'CSET component_name = cnvrt_6_1_47d5ba98a1ac00cb',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '58a2bbf526b07436c5418774edb33708',
    'sourceFile' => 'hdl/xlfpconvert.vhd',
    'templateKeyValues' => {
      'core_component_def' => '    s_axis_a_tvalid: in std_logic;
    s_axis_a_tdata: in std_logic_vector(32 - 1 downto 0) :=(others=>\'0\');
    m_axis_result_tvalid: out std_logic;
    m_axis_result_tdata: out std_logic_vector(32- 1 downto 0) :=(others=>\'0\')',
      'core_instance_text' => '         s_axis_a_tvalid => a_tvalid_net,
         s_axis_a_tdata => a_tdata,
         m_axis_result_tvalid => result_tvalid_net,
         m_axis_result_tdata => result_tdata',
      'core_name0' => 'cnvrt_6_1_47d5ba98a1ac00cb',
      'entityName' => 'xlfpconvert_e_MPPT_BuckMotor_XSG_Implementacion',
      'entity_name.0' => 'xlfpconvert',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '320e413c9d035613395d8bc67aab3c4e',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "00111101001001011001001001000010";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((32 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_a27f724f38',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'ceb46660188fbccdc420237364a5a02b',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "01000000011100001010001111010111";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((32 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_8ecde6f918',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'b2a900ba13304658fbf7e314a4823a2b',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "01000000000100010011111101111101";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((32 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_d5a3cb11f8',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = [
    'SELECT Floating-point artix7 Xilinx,_Inc. 6.1',
    '# 14.5_P.55',
    '# DEVICE artix7',
    '# VHDL',
    'CSET A_Precision_Type = Single',
    'CSET A_TUSER_Width = 1',
    'CSET Add_Sub_Value = Both',
    'CSET Axi_Optimize_Goal = Resources',
    'CSET B_TUSER_Width = 1',
    'CSET C_A_Exponent_Width = 8',
    'CSET C_A_Fraction_Width = 24',
    'CSET C_Compare_Operation = Programmable',
    'CSET C_Has_DIVIDE_BY_ZERO = false',
    'CSET C_Has_INVALID_OP = false',
    'CSET C_Has_OVERFLOW = false',
    'CSET C_Has_UNDERFLOW = false',
    'CSET C_Latency = 0',
    'CSET C_Mult_Usage = No_Usage',
    'CSET C_Optimization = Speed_Optimized',
    'CSET C_Rate = 1',
    'CSET C_Result_Exponent_Width = 8',
    'CSET C_Result_Fraction_Width = 24',
    'CSET Flow_Control = NonBlocking',
    'CSET Has_ACLKEN = false',
    'CSET Has_ARESETn = false',
    'CSET Has_A_TLAST = false',
    'CSET Has_A_TUSER = false',
    'CSET Has_B_TLAST = false',
    'CSET Has_B_TUSER = false',
    'CSET Has_OPERATION_TLAST = false',
    'CSET Has_OPERATION_TUSER = false',
    'CSET Has_RESULT_TREADY = false',
    'CSET Maximum_Latency = false',
    'CSET OPERATION_TUSER_Width = 1',
    'CSET Operation_Type = Multiply',
    'CSET RESULT_TLAST_Behv = Null',
    'CSET Result_Precision_Type = Single',
    'CSET component_name = cmlt_6_1_4a75c1800965883e',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => 'fc817585947f05ec980ecbfe5d11498d',
    'sourceFile' => 'hdl/xlfpcmult.vhd',
    'templateKeyValues' => {
      'core_component_def' => '    s_axis_a_tvalid: in std_logic;
    s_axis_a_tdata: in std_logic_vector(32 - 1 downto 0) :=(others=>\'0\');
    s_axis_b_tvalid: in std_logic;
    s_axis_b_tdata: in std_logic_vector(32 - 1 downto 0) :=(others=>\'0\');
    m_axis_result_tvalid: out std_logic;
    m_axis_result_tdata: out std_logic_vector(32- 1 downto 0) :=(others=>\'0\')',
      'core_instance_text' => '         s_axis_a_tvalid => a_tvalid_net,
         s_axis_a_tdata => a_tdata,
         s_axis_b_tvalid => b_tvalid_net,
         s_axis_b_tdata => b_tdata,
         m_axis_result_tvalid => result_tvalid_net,
         m_axis_result_tdata => result_tdata',
      'core_name0' => 'cmlt_6_1_4a75c1800965883e',
      'entityName' => 'xlfpcmult_e_MPPT_BuckMotor_XSG_Implementacion',
      'entity_name.0' => 'xlfpcmult',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Floating-point artix7 Xilinx,_Inc. 6.1',
    '# 14.5_P.55',
    '# DEVICE artix7',
    '# VHDL',
    'CSET A_Precision_Type = Single',
    'CSET A_TUSER_Width = 1',
    'CSET Add_Sub_Value = Both',
    'CSET Axi_Optimize_Goal = Resources',
    'CSET B_TUSER_Width = 1',
    'CSET C_A_Exponent_Width = 8',
    'CSET C_A_Fraction_Width = 24',
    'CSET C_Compare_Operation = Programmable',
    'CSET C_Has_DIVIDE_BY_ZERO = false',
    'CSET C_Has_INVALID_OP = false',
    'CSET C_Has_OVERFLOW = false',
    'CSET C_Has_UNDERFLOW = false',
    'CSET C_Latency = 0',
    'CSET C_Mult_Usage = No_Usage',
    'CSET C_Optimization = Speed_Optimized',
    'CSET C_Rate = 1',
    'CSET C_Result_Exponent_Width = 8',
    'CSET C_Result_Fraction_Width = 24',
    'CSET Flow_Control = NonBlocking',
    'CSET Has_ACLKEN = false',
    'CSET Has_ARESETn = false',
    'CSET Has_A_TLAST = false',
    'CSET Has_A_TUSER = false',
    'CSET Has_B_TLAST = false',
    'CSET Has_B_TUSER = false',
    'CSET Has_OPERATION_TLAST = false',
    'CSET Has_OPERATION_TUSER = false',
    'CSET Has_RESULT_TREADY = false',
    'CSET Maximum_Latency = false',
    'CSET OPERATION_TUSER_Width = 1',
    'CSET Operation_Type = Multiply',
    'CSET RESULT_TLAST_Behv = Null',
    'CSET Result_Precision_Type = Single',
    'CSET component_name = cmlt_6_1_4a75c1800965883e',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => 'd1e5257e0487f6664e973118220d6b21',
    'sourceFile' => 'hdl/xlfpcmult.vhd',
    'templateKeyValues' => {
      'core_component_def' => '    s_axis_a_tvalid: in std_logic;
    s_axis_a_tdata: in std_logic_vector(32 - 1 downto 0) :=(others=>\'0\');
    s_axis_b_tvalid: in std_logic;
    s_axis_b_tdata: in std_logic_vector(32 - 1 downto 0) :=(others=>\'0\');
    m_axis_result_tvalid: out std_logic;
    m_axis_result_tdata: out std_logic_vector(32- 1 downto 0) :=(others=>\'0\')',
      'core_instance_text' => '         s_axis_a_tvalid => a_tvalid_net,
         s_axis_a_tdata => a_tdata,
         s_axis_b_tvalid => b_tvalid_net,
         s_axis_b_tdata => b_tdata,
         m_axis_result_tvalid => result_tvalid_net,
         m_axis_result_tdata => result_tdata',
      'core_name0' => 'cmlt_6_1_4a75c1800965883e',
      'entityName' => 'xlfpcmult_e_MPPT_BuckMotor_XSG_Implementacion',
      'entity_name.0' => 'xlfpcmult',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Floating-point artix7 Xilinx,_Inc. 6.1',
    '# 14.5_P.55',
    '# DEVICE artix7',
    '# VHDL',
    'CSET A_Precision_Type = Single',
    'CSET A_TUSER_Width = 1',
    'CSET Add_Sub_Value = Both',
    'CSET Axi_Optimize_Goal = Resources',
    'CSET B_TUSER_Width = 1',
    'CSET C_A_Exponent_Width = 8',
    'CSET C_A_Fraction_Width = 24',
    'CSET C_Compare_Operation = Programmable',
    'CSET C_Has_DIVIDE_BY_ZERO = false',
    'CSET C_Has_INVALID_OP = false',
    'CSET C_Has_OVERFLOW = false',
    'CSET C_Has_UNDERFLOW = false',
    'CSET C_Latency = 0',
    'CSET C_Mult_Usage = No_Usage',
    'CSET C_Optimization = Speed_Optimized',
    'CSET C_Rate = 1',
    'CSET C_Result_Exponent_Width = 32',
    'CSET C_Result_Fraction_Width = 0',
    'CSET Flow_Control = NonBlocking',
    'CSET Has_ACLKEN = false',
    'CSET Has_ARESETn = false',
    'CSET Has_A_TLAST = false',
    'CSET Has_A_TUSER = false',
    'CSET Has_B_TLAST = false',
    'CSET Has_B_TUSER = false',
    'CSET Has_OPERATION_TLAST = false',
    'CSET Has_OPERATION_TUSER = false',
    'CSET Has_RESULT_TREADY = false',
    'CSET Maximum_Latency = false',
    'CSET OPERATION_TUSER_Width = 1',
    'CSET Operation_Type = Float_to_fixed',
    'CSET RESULT_TLAST_Behv = Null',
    'CSET Result_Precision_Type = Int32',
    'CSET component_name = cnvrt_6_1_5b7cb79612032685',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '34f3715a8c264e63046ff8a851c85d04',
    'sourceFile' => 'hdl/xlfpconvert.vhd',
    'templateKeyValues' => {
      'core_component_def' => '    s_axis_a_tvalid: in std_logic;
    s_axis_a_tdata: in std_logic_vector(32 - 1 downto 0) :=(others=>\'0\');
    m_axis_result_tvalid: out std_logic;
    m_axis_result_tdata: out std_logic_vector(32- 1 downto 0) :=(others=>\'0\')',
      'core_instance_text' => '         s_axis_a_tvalid => a_tvalid_net,
         s_axis_a_tdata => a_tdata,
         m_axis_result_tvalid => result_tvalid_net,
         m_axis_result_tdata => result_tdata',
      'core_name0' => 'cnvrt_6_1_5b7cb79612032685',
      'entityName' => 'xlfpconvert_e_MPPT_BuckMotor_XSG_Implementacion',
      'entity_name.0' => 'xlfpconvert',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '0451acb8beec36ba6ef5457f987226a0',
    'sourceFile' => 'C:/Xilinx/14.5/ISE_DS/ISE/sysgen/hdl/xlconvert.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'e995d821353c6d202ed7a2e0cd8373f9',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "00110001100010010111000001011111";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((32 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_89be29c4dc',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'bbddb07f3bc24de6cbf79d28d67c491a',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "01000101100111000100000000000000";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((32 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_2c73cea30b',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '03ab1233105defa3415abaf11c81a3fc',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "01000000100000000000000000000000";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((32 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_1f96e05d1e',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'bbc1205fc97ae37a695c85c66b1c8f6c',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "01000000000000000000000000000000";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((32 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_13fc933970',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '9cb548084e8f464459b1ed65df8b83a9',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "01000010011100000000000000000000";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((32 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_2a49f80243',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '383641a3fc3dd88786fe853e778c68d9',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "00111111011001100110011001100110";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((32 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_393213d287',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = [
    'SELECT Floating-point artix7 Xilinx,_Inc. 6.1',
    '# 14.5_P.55',
    '# DEVICE artix7',
    '# VHDL',
    'CSET A_Precision_Type = Single',
    'CSET A_TUSER_Width = 1',
    'CSET Add_Sub_Value = Both',
    'CSET Axi_Optimize_Goal = Resources',
    'CSET B_TUSER_Width = 1',
    'CSET C_A_Exponent_Width = 8',
    'CSET C_A_Fraction_Width = 24',
    'CSET C_Compare_Operation = Programmable',
    'CSET C_Has_DIVIDE_BY_ZERO = false',
    'CSET C_Has_INVALID_OP = false',
    'CSET C_Has_OVERFLOW = false',
    'CSET C_Has_UNDERFLOW = false',
    'CSET C_Latency = 0',
    'CSET C_Mult_Usage = No_Usage',
    'CSET C_Optimization = Speed_Optimized',
    'CSET C_Rate = 1',
    'CSET C_Result_Exponent_Width = 8',
    'CSET C_Result_Fraction_Width = 24',
    'CSET Flow_Control = NonBlocking',
    'CSET Has_ACLKEN = false',
    'CSET Has_ARESETn = false',
    'CSET Has_A_TLAST = false',
    'CSET Has_A_TUSER = false',
    'CSET Has_B_TLAST = false',
    'CSET Has_B_TUSER = false',
    'CSET Has_OPERATION_TLAST = false',
    'CSET Has_OPERATION_TUSER = false',
    'CSET Has_RESULT_TREADY = false',
    'CSET Maximum_Latency = false',
    'CSET OPERATION_TUSER_Width = 1',
    'CSET Operation_Type = Multiply',
    'CSET RESULT_TLAST_Behv = Null',
    'CSET Result_Precision_Type = Single',
    'CSET component_name = cmlt_6_1_4a75c1800965883e',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => 'f4b89a4058177452cbecb7f0aad7fee7',
    'sourceFile' => 'hdl/xlfpcmult.vhd',
    'templateKeyValues' => {
      'core_component_def' => '    s_axis_a_tvalid: in std_logic;
    s_axis_a_tdata: in std_logic_vector(32 - 1 downto 0) :=(others=>\'0\');
    s_axis_b_tvalid: in std_logic;
    s_axis_b_tdata: in std_logic_vector(32 - 1 downto 0) :=(others=>\'0\');
    m_axis_result_tvalid: out std_logic;
    m_axis_result_tdata: out std_logic_vector(32- 1 downto 0) :=(others=>\'0\')',
      'core_instance_text' => '         s_axis_a_tvalid => a_tvalid_net,
         s_axis_a_tdata => a_tdata,
         s_axis_b_tvalid => b_tvalid_net,
         s_axis_b_tdata => b_tdata,
         m_axis_result_tvalid => result_tvalid_net,
         m_axis_result_tdata => result_tdata',
      'core_name0' => 'cmlt_6_1_4a75c1800965883e',
      'entityName' => 'xlfpcmult_e_MPPT_BuckMotor_XSG_Implementacion',
      'entity_name.0' => 'xlfpcmult',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Floating-point artix7 Xilinx,_Inc. 6.1',
    '# 14.5_P.55',
    '# DEVICE artix7',
    '# VHDL',
    'CSET A_Precision_Type = Single',
    'CSET A_TUSER_Width = 1',
    'CSET Add_Sub_Value = Both',
    'CSET Axi_Optimize_Goal = Resources',
    'CSET B_TUSER_Width = 1',
    'CSET C_A_Exponent_Width = 8',
    'CSET C_A_Fraction_Width = 24',
    'CSET C_Compare_Operation = Less_Than',
    'CSET C_Has_DIVIDE_BY_ZERO = false',
    'CSET C_Has_INVALID_OP = false',
    'CSET C_Has_OVERFLOW = false',
    'CSET C_Has_UNDERFLOW = false',
    'CSET C_Latency = 0',
    'CSET C_Mult_Usage = No_Usage',
    'CSET C_Optimization = Speed_Optimized',
    'CSET C_Rate = 1',
    'CSET C_Result_Exponent_Width = 1',
    'CSET C_Result_Fraction_Width = 0',
    'CSET Flow_Control = NonBlocking',
    'CSET Has_ACLKEN = false',
    'CSET Has_ARESETn = false',
    'CSET Has_A_TLAST = false',
    'CSET Has_A_TUSER = false',
    'CSET Has_B_TLAST = false',
    'CSET Has_B_TUSER = false',
    'CSET Has_OPERATION_TLAST = false',
    'CSET Has_OPERATION_TUSER = false',
    'CSET Has_RESULT_TREADY = false',
    'CSET Maximum_Latency = false',
    'CSET OPERATION_TUSER_Width = 1',
    'CSET Operation_Type = Compare',
    'CSET RESULT_TLAST_Behv = Null',
    'CSET Result_Precision_Type = Custom',
    'CSET component_name = rltnl_6_1_ca0014bed731cf1c',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '42cd4a8f5c84842667cb4dc2a91bc1f7',
    'sourceFile' => 'hdl/xlfprelational.vhd',
    'templateKeyValues' => {
      'core_component_def' => '    s_axis_a_tvalid: in std_logic;
    s_axis_a_tdata: in std_logic_vector(32 - 1 downto 0) :=(others=>\'0\');
    s_axis_b_tvalid: in std_logic;
    s_axis_b_tdata: in std_logic_vector(32 - 1 downto 0) :=(others=>\'0\');
    m_axis_result_tvalid: out std_logic;
    m_axis_result_tdata: out std_logic_vector(8- 1 downto 0) :=(others=>\'0\')',
      'core_instance_text' => '         s_axis_a_tvalid => a_tvalid_net,
         s_axis_a_tdata => a_tdata,
         s_axis_b_tvalid => b_tvalid_net,
         s_axis_b_tdata => b_tdata,
         m_axis_result_tvalid => result_tvalid_net,
         m_axis_result_tdata => result_tdata',
      'core_name0' => 'rltnl_6_1_ca0014bed731cf1c',
      'entityName' => 'xlfprelational_e_MPPT_BuckMotor_XSG_Implementacion',
      'entity_name.0' => 'xlfprelational',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'f909a24ca9b5a98d9f4e43542c7e1b3d',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "00111111011011100001010001111011";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((32 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_b206c63f1c',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '3bd508c1b0143f9849f1179f7fc755db',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "01000011111000110100010111010001";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((32 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_5b0a7ba562',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = [
    'SELECT Floating-point artix7 Xilinx,_Inc. 6.1',
    '# 14.5_P.55',
    '# DEVICE artix7',
    '# VHDL',
    'CSET A_Precision_Type = Single',
    'CSET A_TUSER_Width = 1',
    'CSET Add_Sub_Value = Add',
    'CSET Axi_Optimize_Goal = Resources',
    'CSET B_TUSER_Width = 1',
    'CSET C_A_Exponent_Width = 8',
    'CSET C_A_Fraction_Width = 24',
    'CSET C_Compare_Operation = Programmable',
    'CSET C_Has_DIVIDE_BY_ZERO = false',
    'CSET C_Has_INVALID_OP = false',
    'CSET C_Has_OVERFLOW = false',
    'CSET C_Has_UNDERFLOW = false',
    'CSET C_Latency = 0',
    'CSET C_Mult_Usage = Full_Usage',
    'CSET C_Optimization = Speed_Optimized',
    'CSET C_Rate = 1',
    'CSET C_Result_Exponent_Width = 8',
    'CSET C_Result_Fraction_Width = 24',
    'CSET Flow_Control = NonBlocking',
    'CSET Has_ACLKEN = false',
    'CSET Has_ARESETn = false',
    'CSET Has_A_TLAST = false',
    'CSET Has_A_TUSER = false',
    'CSET Has_B_TLAST = false',
    'CSET Has_B_TUSER = false',
    'CSET Has_OPERATION_TLAST = false',
    'CSET Has_OPERATION_TUSER = false',
    'CSET Has_RESULT_TREADY = false',
    'CSET Maximum_Latency = false',
    'CSET OPERATION_TUSER_Width = 1',
    'CSET Operation_Type = Add_Subtract',
    'CSET RESULT_TLAST_Behv = Null',
    'CSET Result_Precision_Type = Single',
    'CSET component_name = addsb_6_1_9abe00158dbc40e2',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '2b18f30517e3d88f12d48651b157260d',
    'sourceFile' => 'hdl/xlfpaddsub.vhd',
    'templateKeyValues' => {
      'core_component_def' => '    s_axis_a_tvalid: in std_logic;
    s_axis_a_tdata: in std_logic_vector(32 - 1 downto 0) :=(others=>\'0\');
    s_axis_b_tvalid: in std_logic;
    s_axis_b_tdata: in std_logic_vector(32 - 1 downto 0) :=(others=>\'0\');
    m_axis_result_tvalid: out std_logic;
    m_axis_result_tdata: out std_logic_vector(32- 1 downto 0) :=(others=>\'0\')',
      'core_instance_text' => '         s_axis_a_tvalid => a_tvalid_net,
         s_axis_a_tdata => a_tdata,
         s_axis_b_tvalid => b_tvalid_net,
         s_axis_b_tdata => b_tdata,
         m_axis_result_tvalid => result_tvalid_net,
         m_axis_result_tdata => result_tdata',
      'core_name0' => 'addsb_6_1_9abe00158dbc40e2',
      'entityName' => 'xlfpaddsub_e_MPPT_BuckMotor_XSG_Implementacion',
      'entity_name.0' => 'xlfpaddsub',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Floating-point artix7 Xilinx,_Inc. 6.1',
    '# 14.5_P.55',
    '# DEVICE artix7',
    '# VHDL',
    'CSET A_Precision_Type = Single',
    'CSET A_TUSER_Width = 1',
    'CSET Add_Sub_Value = Subtract',
    'CSET Axi_Optimize_Goal = Resources',
    'CSET B_TUSER_Width = 1',
    'CSET C_A_Exponent_Width = 8',
    'CSET C_A_Fraction_Width = 24',
    'CSET C_Compare_Operation = Programmable',
    'CSET C_Has_DIVIDE_BY_ZERO = false',
    'CSET C_Has_INVALID_OP = false',
    'CSET C_Has_OVERFLOW = false',
    'CSET C_Has_UNDERFLOW = false',
    'CSET C_Latency = 0',
    'CSET C_Mult_Usage = Full_Usage',
    'CSET C_Optimization = Speed_Optimized',
    'CSET C_Rate = 1',
    'CSET C_Result_Exponent_Width = 8',
    'CSET C_Result_Fraction_Width = 24',
    'CSET Flow_Control = NonBlocking',
    'CSET Has_ACLKEN = false',
    'CSET Has_ARESETn = false',
    'CSET Has_A_TLAST = false',
    'CSET Has_A_TUSER = false',
    'CSET Has_B_TLAST = false',
    'CSET Has_B_TUSER = false',
    'CSET Has_OPERATION_TLAST = false',
    'CSET Has_OPERATION_TUSER = false',
    'CSET Has_RESULT_TREADY = false',
    'CSET Maximum_Latency = false',
    'CSET OPERATION_TUSER_Width = 1',
    'CSET Operation_Type = Add_Subtract',
    'CSET RESULT_TLAST_Behv = Null',
    'CSET Result_Precision_Type = Single',
    'CSET component_name = addsb_6_1_3f1c10c2e8613eb8',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '5445d6e4004c1b711b65090d6da71096',
    'sourceFile' => 'hdl/xlfpaddsub.vhd',
    'templateKeyValues' => {
      'core_component_def' => '    s_axis_a_tvalid: in std_logic;
    s_axis_a_tdata: in std_logic_vector(32 - 1 downto 0) :=(others=>\'0\');
    s_axis_b_tvalid: in std_logic;
    s_axis_b_tdata: in std_logic_vector(32 - 1 downto 0) :=(others=>\'0\');
    m_axis_result_tvalid: out std_logic;
    m_axis_result_tdata: out std_logic_vector(32- 1 downto 0) :=(others=>\'0\')',
      'core_instance_text' => '         s_axis_a_tvalid => a_tvalid_net,
         s_axis_a_tdata => a_tdata,
         s_axis_b_tvalid => b_tvalid_net,
         s_axis_b_tdata => b_tdata,
         m_axis_result_tvalid => result_tvalid_net,
         m_axis_result_tdata => result_tdata',
      'core_name0' => 'addsb_6_1_3f1c10c2e8613eb8',
      'entityName' => 'xlfpaddsub_e_MPPT_BuckMotor_XSG_Implementacion',
      'entity_name.0' => 'xlfpaddsub',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '3eb7c47169ea8b248b118da571d60a71',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "00111011001000111101011100001010";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((32 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_e452f672c7',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '5baa819ac569d6efb7dda2467a719ea9',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "00111110101100110011001100110011";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((32 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_a0d9370ce7',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = [
    'SELECT Floating-point artix7 Xilinx,_Inc. 6.1',
    '# 14.5_P.55',
    '# DEVICE artix7',
    '# VHDL',
    'CSET A_Precision_Type = Single',
    'CSET A_TUSER_Width = 1',
    'CSET Add_Sub_Value = Both',
    'CSET Axi_Optimize_Goal = Resources',
    'CSET B_TUSER_Width = 1',
    'CSET C_A_Exponent_Width = 8',
    'CSET C_A_Fraction_Width = 24',
    'CSET C_Compare_Operation = Programmable',
    'CSET C_Has_DIVIDE_BY_ZERO = false',
    'CSET C_Has_INVALID_OP = false',
    'CSET C_Has_OVERFLOW = false',
    'CSET C_Has_UNDERFLOW = false',
    'CSET C_Latency = 0',
    'CSET C_Mult_Usage = No_Usage',
    'CSET C_Optimization = Speed_Optimized',
    'CSET C_Rate = 1',
    'CSET C_Result_Exponent_Width = 8',
    'CSET C_Result_Fraction_Width = 24',
    'CSET Flow_Control = NonBlocking',
    'CSET Has_ACLKEN = false',
    'CSET Has_ARESETn = false',
    'CSET Has_A_TLAST = false',
    'CSET Has_A_TUSER = false',
    'CSET Has_B_TLAST = false',
    'CSET Has_B_TUSER = false',
    'CSET Has_OPERATION_TLAST = false',
    'CSET Has_OPERATION_TUSER = false',
    'CSET Has_RESULT_TREADY = false',
    'CSET Maximum_Latency = false',
    'CSET OPERATION_TUSER_Width = 1',
    'CSET Operation_Type = Multiply',
    'CSET RESULT_TLAST_Behv = Null',
    'CSET Result_Precision_Type = Single',
    'CSET component_name = cmlt_6_1_4a75c1800965883e',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '8ca59225cd4d92ea6d71f7dfe444192e',
    'sourceFile' => 'hdl/xlfpcmult.vhd',
    'templateKeyValues' => {
      'core_component_def' => '    s_axis_a_tvalid: in std_logic;
    s_axis_a_tdata: in std_logic_vector(32 - 1 downto 0) :=(others=>\'0\');
    s_axis_b_tvalid: in std_logic;
    s_axis_b_tdata: in std_logic_vector(32 - 1 downto 0) :=(others=>\'0\');
    m_axis_result_tvalid: out std_logic;
    m_axis_result_tdata: out std_logic_vector(32- 1 downto 0) :=(others=>\'0\')',
      'core_instance_text' => '         s_axis_a_tvalid => a_tvalid_net,
         s_axis_a_tdata => a_tdata,
         s_axis_b_tvalid => b_tvalid_net,
         s_axis_b_tdata => b_tdata,
         m_axis_result_tvalid => result_tvalid_net,
         m_axis_result_tdata => result_tdata',
      'core_name0' => 'cmlt_6_1_4a75c1800965883e',
      'entityName' => 'xlfpcmult_e_MPPT_BuckMotor_XSG_Implementacion',
      'entity_name.0' => 'xlfpcmult',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '781b4cee9dd3d3d5a3f69f6c1c2f2555',
    'sourceFile' => 'C:/Xilinx/14.5/ISE_DS/ISE/sysgen/hdl/xldelay.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '39052efd288964a4014331bd66bf22fb',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "00110110000001100011011110111101";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((32 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_7505ebe54d',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = [
    'SELECT Floating-point artix7 Xilinx,_Inc. 6.1',
    '# 14.5_P.55',
    '# DEVICE artix7',
    '# VHDL',
    'CSET A_Precision_Type = Single',
    'CSET A_TUSER_Width = 1',
    'CSET Add_Sub_Value = Subtract',
    'CSET Axi_Optimize_Goal = Resources',
    'CSET B_TUSER_Width = 1',
    'CSET C_A_Exponent_Width = 8',
    'CSET C_A_Fraction_Width = 24',
    'CSET C_Compare_Operation = Programmable',
    'CSET C_Has_DIVIDE_BY_ZERO = false',
    'CSET C_Has_INVALID_OP = false',
    'CSET C_Has_OVERFLOW = false',
    'CSET C_Has_UNDERFLOW = false',
    'CSET C_Latency = 1',
    'CSET C_Mult_Usage = No_Usage',
    'CSET C_Optimization = Speed_Optimized',
    'CSET C_Rate = 1',
    'CSET C_Result_Exponent_Width = 8',
    'CSET C_Result_Fraction_Width = 24',
    'CSET Flow_Control = NonBlocking',
    'CSET Has_ACLKEN = true',
    'CSET Has_ARESETn = false',
    'CSET Has_A_TLAST = false',
    'CSET Has_A_TUSER = false',
    'CSET Has_B_TLAST = false',
    'CSET Has_B_TUSER = false',
    'CSET Has_OPERATION_TLAST = false',
    'CSET Has_OPERATION_TUSER = false',
    'CSET Has_RESULT_TREADY = false',
    'CSET Maximum_Latency = false',
    'CSET OPERATION_TUSER_Width = 1',
    'CSET Operation_Type = Add_Subtract',
    'CSET RESULT_TLAST_Behv = Null',
    'CSET Result_Precision_Type = Single',
    'CSET component_name = addsb_6_1_9302928534302d88',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '87a191146fb288c28b490a92985b7090',
    'sourceFile' => 'hdl/xlfpaddsub.vhd',
    'templateKeyValues' => {
      'core_component_def' => '    s_axis_a_tvalid: in std_logic;
    s_axis_a_tdata: in std_logic_vector(32 - 1 downto 0) :=(others=>\'0\');
    s_axis_b_tvalid: in std_logic;
    s_axis_b_tdata: in std_logic_vector(32 - 1 downto 0) :=(others=>\'0\');
    aclk: in std_logic:= \'0\';
    aclken: in std_logic:= \'1\';
    m_axis_result_tvalid: out std_logic;
    m_axis_result_tdata: out std_logic_vector(32- 1 downto 0) :=(others=>\'0\')',
      'core_instance_text' => '         s_axis_a_tvalid => a_tvalid_net,
         s_axis_a_tdata => a_tdata,
         s_axis_b_tvalid => b_tvalid_net,
         s_axis_b_tdata => b_tdata,
         aclk => clk,
         aclken => internal_ce,
         m_axis_result_tvalid => result_tvalid_net,
         m_axis_result_tdata => result_tdata',
      'core_name0' => 'addsb_6_1_9302928534302d88',
      'entityName' => 'xlfpaddsub_e_MPPT_BuckMotor_XSG_Implementacion',
      'entity_name.0' => 'xlfpaddsub',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'e9b1771c90c206ea0e94ac3d6fe1f198',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "01000011111110100000000000000000";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((32 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_f8dcff670f',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = [
    'SELECT Floating-point artix7 Xilinx,_Inc. 6.1',
    '# 14.5_P.55',
    '# DEVICE artix7',
    '# VHDL',
    'CSET A_Precision_Type = Single',
    'CSET A_TUSER_Width = 1',
    'CSET Add_Sub_Value = Both',
    'CSET Axi_Optimize_Goal = Resources',
    'CSET B_TUSER_Width = 1',
    'CSET C_A_Exponent_Width = 8',
    'CSET C_A_Fraction_Width = 24',
    'CSET C_Compare_Operation = Programmable',
    'CSET C_Has_DIVIDE_BY_ZERO = false',
    'CSET C_Has_INVALID_OP = false',
    'CSET C_Has_OVERFLOW = false',
    'CSET C_Has_UNDERFLOW = false',
    'CSET C_Latency = 0',
    'CSET C_Mult_Usage = No_Usage',
    'CSET C_Optimization = Speed_Optimized',
    'CSET C_Rate = 1',
    'CSET C_Result_Exponent_Width = 8',
    'CSET C_Result_Fraction_Width = 24',
    'CSET Flow_Control = NonBlocking',
    'CSET Has_ACLKEN = false',
    'CSET Has_ARESETn = false',
    'CSET Has_A_TLAST = false',
    'CSET Has_A_TUSER = false',
    'CSET Has_B_TLAST = false',
    'CSET Has_B_TUSER = false',
    'CSET Has_OPERATION_TLAST = false',
    'CSET Has_OPERATION_TUSER = false',
    'CSET Has_RESULT_TREADY = false',
    'CSET Maximum_Latency = false',
    'CSET OPERATION_TUSER_Width = 1',
    'CSET Operation_Type = Multiply',
    'CSET RESULT_TLAST_Behv = Null',
    'CSET Result_Precision_Type = Single',
    'CSET component_name = cmlt_6_1_4a75c1800965883e',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => 'c32310b31f8d28b08498bc06d264980c',
    'sourceFile' => 'hdl/xlfpcmult.vhd',
    'templateKeyValues' => {
      'core_component_def' => '    s_axis_a_tvalid: in std_logic;
    s_axis_a_tdata: in std_logic_vector(32 - 1 downto 0) :=(others=>\'0\');
    s_axis_b_tvalid: in std_logic;
    s_axis_b_tdata: in std_logic_vector(32 - 1 downto 0) :=(others=>\'0\');
    m_axis_result_tvalid: out std_logic;
    m_axis_result_tdata: out std_logic_vector(32- 1 downto 0) :=(others=>\'0\')',
      'core_instance_text' => '         s_axis_a_tvalid => a_tvalid_net,
         s_axis_a_tdata => a_tdata,
         s_axis_b_tvalid => b_tvalid_net,
         s_axis_b_tdata => b_tdata,
         m_axis_result_tvalid => result_tvalid_net,
         m_axis_result_tdata => result_tdata',
      'core_name0' => 'cmlt_6_1_4a75c1800965883e',
      'entityName' => 'xlfpcmult_e_MPPT_BuckMotor_XSG_Implementacion',
      'entity_name.0' => 'xlfpcmult',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Floating-point artix7 Xilinx,_Inc. 6.1',
    '# 14.5_P.55',
    '# DEVICE artix7',
    '# VHDL',
    'CSET A_Precision_Type = Single',
    'CSET A_TUSER_Width = 1',
    'CSET Add_Sub_Value = Both',
    'CSET Axi_Optimize_Goal = Resources',
    'CSET B_TUSER_Width = 1',
    'CSET C_A_Exponent_Width = 8',
    'CSET C_A_Fraction_Width = 24',
    'CSET C_Compare_Operation = Programmable',
    'CSET C_Has_DIVIDE_BY_ZERO = false',
    'CSET C_Has_INVALID_OP = false',
    'CSET C_Has_OVERFLOW = false',
    'CSET C_Has_UNDERFLOW = false',
    'CSET C_Latency = 0',
    'CSET C_Mult_Usage = No_Usage',
    'CSET C_Optimization = Speed_Optimized',
    'CSET C_Rate = 1',
    'CSET C_Result_Exponent_Width = 8',
    'CSET C_Result_Fraction_Width = 24',
    'CSET Flow_Control = NonBlocking',
    'CSET Has_ACLKEN = false',
    'CSET Has_ARESETn = false',
    'CSET Has_A_TLAST = false',
    'CSET Has_A_TUSER = false',
    'CSET Has_B_TLAST = false',
    'CSET Has_B_TUSER = false',
    'CSET Has_OPERATION_TLAST = false',
    'CSET Has_OPERATION_TUSER = false',
    'CSET Has_RESULT_TREADY = false',
    'CSET Maximum_Latency = false',
    'CSET OPERATION_TUSER_Width = 1',
    'CSET Operation_Type = Multiply',
    'CSET RESULT_TLAST_Behv = Null',
    'CSET Result_Precision_Type = Single',
    'CSET component_name = cmlt_6_1_4a75c1800965883e',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => 'fe4accbe5e739106bd539b9f97952bb1',
    'sourceFile' => 'hdl/xlfpcmult.vhd',
    'templateKeyValues' => {
      'core_component_def' => '    s_axis_a_tvalid: in std_logic;
    s_axis_a_tdata: in std_logic_vector(32 - 1 downto 0) :=(others=>\'0\');
    s_axis_b_tvalid: in std_logic;
    s_axis_b_tdata: in std_logic_vector(32 - 1 downto 0) :=(others=>\'0\');
    m_axis_result_tvalid: out std_logic;
    m_axis_result_tdata: out std_logic_vector(32- 1 downto 0) :=(others=>\'0\')',
      'core_instance_text' => '         s_axis_a_tvalid => a_tvalid_net,
         s_axis_a_tdata => a_tdata,
         s_axis_b_tvalid => b_tvalid_net,
         s_axis_b_tdata => b_tdata,
         m_axis_result_tvalid => result_tvalid_net,
         m_axis_result_tdata => result_tdata',
      'core_name0' => 'cmlt_6_1_4a75c1800965883e',
      'entityName' => 'xlfpcmult_e_MPPT_BuckMotor_XSG_Implementacion',
      'entity_name.0' => 'xlfpcmult',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '562fdf4b0f82c9b44438acc2b62198cf',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "01010010101101011101111110010010";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((32 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_180c35caf2',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '32371d6e390513ed5e1d5cd2dd2aba16',
    'sourceFile' => 'C:/Xilinx/14.5/ISE_DS/ISE/sysgen/hdl/xlregister.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '57530596858ed77a9588ba63aaeaa7e9',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "01000011100101100000000000000000";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((32 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_0d034e93e3',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '29c67c001d9aea264e5e67001211affe',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "01000100000101100000000000000000";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((32 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_3e18a698c1',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '7640ff7b8bdc5fade17de7171051fed0',
    'sourceFile' => 'C:/Users/alber/Documents/UTM - Maestria/Tesis Maestria/6 Implementacion XSG/delay1ms.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '298203483c3de52896eed04fd75246a4',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
  signal d0_1_24: std_logic;
  signal d1_1_27: std_logic;
  signal fully_2_1_bit: std_logic;
begin
  d0_1_24 <= d0(0);
  d1_1_27 <= d1(0);
  fully_2_1_bit <= d0_1_24 and d1_1_27;
  y <= std_logic_to_vector(fully_2_1_bit);
end',
      'crippled_entity' => 'is
  port (
    d0 : in std_logic_vector((1 - 1) downto 0);
    d1 : in std_logic_vector((1 - 1) downto 0);
    y : out std_logic_vector((1 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'logical_80f90b97d0',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'ea080f6d5d9c1e987228264f74096c3a',
    'sourceFile' => 'C:/Xilinx/14.5/ISE_DS/ISE/sysgen/hdl/xlconvert.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'bfe5327cfab83bbe8bde5907a0b3dd34',
    'sourceFile' => 'C:/Users/alber/Documents/UTM - Maestria/Tesis Maestria/6 Implementacion XSG/delay.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Adder_Subtracter artix7 Xilinx,_Inc. 11.0',
    '# 14.5_P.55',
    '# DEVICE artix7',
    '# VHDL',
    'CSET AINIT_Value = 0',
    'CSET A_Type = Signed',
    'CSET A_Width = 12',
    'CSET Add_Mode = Subtract',
    'CSET B_Constant = false',
    'CSET B_Type = Signed',
    'CSET B_Value = 0',
    'CSET B_Width = 12',
    'CSET Borrow_Sense = Active_Low',
    'CSET Bypass = false',
    'CSET Bypass_CE_Priority = Bypass_Overrides_CE',
    'CSET Bypass_Sense = Active_Low',
    'CSET CE = false',
    'CSET C_In = false',
    'CSET C_Out = false',
    'CSET Implementation = Fabric',
    'CSET Latency = 0',
    'CSET Out_Width = 12',
    'CSET SCLR = false',
    'CSET SINIT = false',
    'CSET SINIT_Value = 0',
    'CSET SSET = false',
    'CSET Sync_CE_Priority = Sync_Overrides_CE',
    'CSET Sync_Ctrl_Priority = Reset_Overrides_Set',
    'CSET component_name = addsb_11_0_3f3c21fdd660b54f',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '5a93f18a9802790d135a6306c411940f',
    'sourceFile' => 'hdl/xladdsub.vhd',
    'templateKeyValues' => {
      'core_component_def' => '    a: in std_logic_vector(12 - 1 downto 0);
    s: out std_logic_vector(c_output_width - 1 downto 0);
    b: in std_logic_vector(12 - 1 downto 0)',
      'core_instance_text' => '         a => full_a,
         s => core_s,
         b => full_b',
      'core_name0' => 'addsb_11_0_3f3c21fdd660b54f',
      'entityName' => 'xladdsub_e_MPPT_BuckMotor_XSG_Implementacion',
      'entity_name.0' => 'xladdsub',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Floating-point artix7 Xilinx,_Inc. 6.1',
    '# 14.5_P.55',
    '# DEVICE artix7',
    '# VHDL',
    'CSET A_Precision_Type = Single',
    'CSET A_TUSER_Width = 1',
    'CSET Add_Sub_Value = Both',
    'CSET Axi_Optimize_Goal = Resources',
    'CSET B_TUSER_Width = 1',
    'CSET C_A_Exponent_Width = 8',
    'CSET C_A_Fraction_Width = 24',
    'CSET C_Compare_Operation = Programmable',
    'CSET C_Has_DIVIDE_BY_ZERO = false',
    'CSET C_Has_INVALID_OP = false',
    'CSET C_Has_OVERFLOW = false',
    'CSET C_Has_UNDERFLOW = false',
    'CSET C_Latency = 0',
    'CSET C_Mult_Usage = No_Usage',
    'CSET C_Optimization = Speed_Optimized',
    'CSET C_Rate = 1',
    'CSET C_Result_Exponent_Width = 8',
    'CSET C_Result_Fraction_Width = 24',
    'CSET Flow_Control = NonBlocking',
    'CSET Has_ACLKEN = false',
    'CSET Has_ARESETn = false',
    'CSET Has_A_TLAST = false',
    'CSET Has_A_TUSER = false',
    'CSET Has_B_TLAST = false',
    'CSET Has_B_TUSER = false',
    'CSET Has_OPERATION_TLAST = false',
    'CSET Has_OPERATION_TUSER = false',
    'CSET Has_RESULT_TREADY = false',
    'CSET Maximum_Latency = false',
    'CSET OPERATION_TUSER_Width = 1',
    'CSET Operation_Type = Multiply',
    'CSET RESULT_TLAST_Behv = Null',
    'CSET Result_Precision_Type = Single',
    'CSET component_name = cmlt_6_1_4a75c1800965883e',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => 'dda59ffa3dfa2fe792ffe11da01f13ea',
    'sourceFile' => 'hdl/xlfpcmult.vhd',
    'templateKeyValues' => {
      'core_component_def' => '    s_axis_a_tvalid: in std_logic;
    s_axis_a_tdata: in std_logic_vector(32 - 1 downto 0) :=(others=>\'0\');
    s_axis_b_tvalid: in std_logic;
    s_axis_b_tdata: in std_logic_vector(32 - 1 downto 0) :=(others=>\'0\');
    m_axis_result_tvalid: out std_logic;
    m_axis_result_tdata: out std_logic_vector(32- 1 downto 0) :=(others=>\'0\')',
      'core_instance_text' => '         s_axis_a_tvalid => a_tvalid_net,
         s_axis_a_tdata => a_tdata,
         s_axis_b_tvalid => b_tvalid_net,
         s_axis_b_tdata => b_tdata,
         m_axis_result_tvalid => result_tvalid_net,
         m_axis_result_tdata => result_tdata',
      'core_name0' => 'cmlt_6_1_4a75c1800965883e',
      'entityName' => 'xlfpcmult_e_MPPT_BuckMotor_XSG_Implementacion',
      'entity_name.0' => 'xlfpcmult',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '9b86ce097634cf967a181fb3fbe251aa',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "0000000000000000";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((16 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_9f5572ba51',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'ea4ca48a4be7700f25438c890c9fc10a',
    'sourceFile' => 'C:/Xilinx/14.5/ISE_DS/ISE/sysgen/hdl/xlconvert.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = [
    'SELECT Binary_Counter artix7 Xilinx,_Inc. 11.0',
    '# 14.5_P.55',
    '# DEVICE artix7',
    '# VHDL',
    'CSET ainit_value = 0',
    'CSET ce = true',
    'CSET count_mode = UP',
    'CSET fb_latency = 0',
    'CSET final_count_value = 1',
    'CSET implementation = Fabric',
    'CSET increment_value = 1',
    'CSET latency = 1',
    'CSET load = false',
    'CSET output_width = 11',
    'CSET restrict_count = false',
    'CSET sclr = false',
    'CSET sinit = true',
    'CSET sinit_value = 0',
    'CSET sset = false',
    'CSET sync_ce_priority = Sync_Overrides_CE',
    'CSET sync_threshold_output = false',
    'CSET syncctrlpriority = Reset_Overrides_Set',
    'CSET component_name = cntr_11_0_de3184725b5c481e',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => '0605f7efae7f58ffc4d0e5f972125b00',
    'sourceFile' => 'hdl/xlcounter_limit.vhd',
    'templateKeyValues' => {
      'core_component_def' => '      clk: in std_logic;
      ce: in std_logic;
      SINIT: in std_logic;
      q: out std_logic_vector(op_width - 1 downto 0)',
      'core_instance_text' => '        clk => clk,
        ce => core_ce,
        SINIT => core_sinit,
        q => op_net',
      'core_name0' => 'cntr_11_0_de3184725b5c481e',
      'entityName' => 'xlcounter_limit_e_MPPT_BuckMotor_XSG_Implementacion',
      'entity_name.0' => 'xlcounter_limit',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'd13641071c63bc4972d6c5bd8ce8315d',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "00111101110011001100110011001101";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((32 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_9a574d1be3',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'c187eee38d8ef413e61fa582bd6238fd',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "00111111011010111000010100011111";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((32 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_eb2017ba0f',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => '568d2e58d4ed81c93620eb456bacc274',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
  signal a_1_31: signed((12 - 1) downto 0);
  signal b_1_34: signed((16 - 1) downto 0);
  signal cast_18_12: signed((26 - 1) downto 0);
  signal cast_18_16: signed((26 - 1) downto 0);
  signal result_18_3_rel: boolean;
begin
  a_1_31 <= std_logic_vector_to_signed(a);
  b_1_34 <= std_logic_vector_to_signed(b);
  cast_18_12 <= s2s_cast(a_1_31, 0, 26, 14);
  cast_18_16 <= s2s_cast(b_1_34, 14, 26, 14);
  result_18_3_rel <= cast_18_12 > cast_18_16;
  op <= boolean_to_vector(result_18_3_rel);
end',
      'crippled_entity' => 'is
  port (
    a : in std_logic_vector((12 - 1) downto 0);
    b : in std_logic_vector((16 - 1) downto 0);
    op : out std_logic_vector((1 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'relational_38048f1588',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = [
    'SELECT Floating-point artix7 Xilinx,_Inc. 6.1',
    '# 14.5_P.55',
    '# DEVICE artix7',
    '# VHDL',
    'CSET A_Precision_Type = Single',
    'CSET A_TUSER_Width = 1',
    'CSET Add_Sub_Value = Both',
    'CSET Axi_Optimize_Goal = Resources',
    'CSET B_TUSER_Width = 1',
    'CSET C_A_Exponent_Width = 8',
    'CSET C_A_Fraction_Width = 24',
    'CSET C_Compare_Operation = Greater_Than_Or_Equal',
    'CSET C_Has_DIVIDE_BY_ZERO = false',
    'CSET C_Has_INVALID_OP = false',
    'CSET C_Has_OVERFLOW = false',
    'CSET C_Has_UNDERFLOW = false',
    'CSET C_Latency = 0',
    'CSET C_Mult_Usage = No_Usage',
    'CSET C_Optimization = Speed_Optimized',
    'CSET C_Rate = 1',
    'CSET C_Result_Exponent_Width = 1',
    'CSET C_Result_Fraction_Width = 0',
    'CSET Flow_Control = NonBlocking',
    'CSET Has_ACLKEN = false',
    'CSET Has_ARESETn = false',
    'CSET Has_A_TLAST = false',
    'CSET Has_A_TUSER = false',
    'CSET Has_B_TLAST = false',
    'CSET Has_B_TUSER = false',
    'CSET Has_OPERATION_TLAST = false',
    'CSET Has_OPERATION_TUSER = false',
    'CSET Has_RESULT_TREADY = false',
    'CSET Maximum_Latency = false',
    'CSET OPERATION_TUSER_Width = 1',
    'CSET Operation_Type = Compare',
    'CSET RESULT_TLAST_Behv = Null',
    'CSET Result_Precision_Type = Custom',
    'CSET component_name = rltnl_6_1_b6f070e6246d803f',
    'GENERATE',
  ];
  push(@$results, &SgGenerateCores::saveXcoSequence($instrs));
  $instrs = {
    'entity_declaration_hash' => 'd2018ada83b5ca8894882ac6df002ade',
    'sourceFile' => 'hdl/xlfprelational.vhd',
    'templateKeyValues' => {
      'core_component_def' => '    s_axis_a_tvalid: in std_logic;
    s_axis_a_tdata: in std_logic_vector(32 - 1 downto 0) :=(others=>\'0\');
    s_axis_b_tvalid: in std_logic;
    s_axis_b_tdata: in std_logic_vector(32 - 1 downto 0) :=(others=>\'0\');
    m_axis_result_tvalid: out std_logic;
    m_axis_result_tdata: out std_logic_vector(8- 1 downto 0) :=(others=>\'0\')',
      'core_instance_text' => '         s_axis_a_tvalid => a_tvalid_net,
         s_axis_a_tdata => a_tdata,
         s_axis_b_tvalid => b_tvalid_net,
         s_axis_b_tdata => b_tdata,
         m_axis_result_tvalid => result_tvalid_net,
         m_axis_result_tdata => result_tdata',
      'core_name0' => 'rltnl_6_1_b6f070e6246d803f',
      'entityName' => 'xlfprelational_e_MPPT_BuckMotor_XSG_Implementacion',
      'entity_name.0' => 'xlfprelational',
      'needs_core' => 1,
      'vivado_flow' => 0,
    },
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '2ce14483830e1321a327ac58ff22567d',
    'sourceFile' => 'C:/Users/alber/Documents/UTM - Maestria/Tesis Maestria/6 Implementacion XSG/dac.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'ace4230e73962dcc3b53d56f101f8ee2',
    'sourceFile' => 'C:/Users/alber/Documents/UTM - Maestria/Tesis Maestria/6 Implementacion XSG/dac2.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => 'd265854b7aa4481fbcc9fc4aef5a019a',
    'sourceFile' => 'C:/Users/alber/Documents/UTM - Maestria/Tesis Maestria/6 Implementacion XSG/adc1ms.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '101b39ed99787a435734cd69aa965f95',
    'sourceFile' => 'C:/Users/alber/Documents/UTM - Maestria/Tesis Maestria/6 Implementacion XSG/adc2.vhd',
  };
  push(@$results, &SgDeliverFile::saveCollaborationInfo($instrs));
  $instrs = {
    'entity_declaration_hash' => '1469eb6d731d162e76ab1cf1a528a599',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "01000010010010000000000000000000";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((32 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_49e03fa116',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  $instrs = {
    'entity_declaration_hash' => 'f926b66a30424c6f6149f4fd46f8df68',
    'sourceFile' => 'hdl/xlmcode.vhd',
    'templateKeyValues' => {
      'crippled_architecture' => 'is
begin
  op <= "01000011000100010000000000000000";
end',
      'crippled_entity' => 'is
  port (
    op : out std_logic_vector((32 - 1) downto 0);
    clk : in std_logic;
    ce : in std_logic;
    clr : in std_logic);
end',
      'entity_name' => 'constant_3c11608b27',
    },
  };
  push(@$results, &SgDeliverFile::deliverFile($instrs));
  local *wrapup = $Sg::{'wrapup'};
  push(@$results, &Sg::wrapup())   if (defined(&wrapup));
  local *wrapup = $SgDeliverFile::{'wrapup'};
  push(@$results, &SgDeliverFile::wrapup())   if (defined(&wrapup));
  local *wrapup = $SgGenerateCores::{'wrapup'};
  push(@$results, &SgGenerateCores::wrapup())   if (defined(&wrapup));
  use Carp qw(croak);
  $ENV{'SYSGEN'} = 'C:/Xilinx/14.5/ISE_DS/ISE/sysgen';
  open(RESULTS, '> C:/Users/alber/Documents/UTM - Maestria/Tesis Maestria/6 Implementacion XSG/netlist/sysgen/script_results1809375994145406662') || 
    croak 'couldn\'t open C:/Users/alber/Documents/UTM - Maestria/Tesis Maestria/6 Implementacion XSG/netlist/sysgen/script_results1809375994145406662';
  binmode(RESULTS);
  print RESULTS &Sg::toString($results) . "\n";
  close(RESULTS) || 
    croak 'trouble writing C:/Users/alber/Documents/UTM - Maestria/Tesis Maestria/6 Implementacion XSG/netlist/sysgen/script_results1809375994145406662';
};

if ($@) {
  open(RESULTS, '> C:/Users/alber/Documents/UTM - Maestria/Tesis Maestria/6 Implementacion XSG/netlist/sysgen/script_results1809375994145406662') || 
    croak 'couldn\'t open C:/Users/alber/Documents/UTM - Maestria/Tesis Maestria/6 Implementacion XSG/netlist/sysgen/script_results1809375994145406662';
  binmode(RESULTS);
  print RESULTS $@ . "\n";
  close(RESULTS) || 
    croak 'trouble writing C:/Users/alber/Documents/UTM - Maestria/Tesis Maestria/6 Implementacion XSG/netlist/sysgen/script_results1809375994145406662';
  exit(1);
}

exit(0);
